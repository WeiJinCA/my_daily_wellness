package com.example.my_daily_wellness

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
